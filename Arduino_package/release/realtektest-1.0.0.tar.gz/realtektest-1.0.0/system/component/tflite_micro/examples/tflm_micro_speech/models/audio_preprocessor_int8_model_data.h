#include <cstdint>

constexpr unsigned int g_audio_preprocessor_int8_model_data_size = 8772;
extern const unsigned char g_audio_preprocessor_int8_model_data[];
