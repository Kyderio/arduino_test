#include <cstdint>

constexpr unsigned int g_yes_30ms_audio_data_size = 480;
extern const int16_t g_yes_30ms_audio_data[];
