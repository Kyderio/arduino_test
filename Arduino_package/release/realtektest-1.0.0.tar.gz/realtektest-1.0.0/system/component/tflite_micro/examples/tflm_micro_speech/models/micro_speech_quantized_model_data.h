#include <cstdint>

constexpr unsigned int g_micro_speech_quantized_model_data_size = 18800;
extern const unsigned char g_micro_speech_quantized_model_data[];
