#include <cstdint>

constexpr unsigned int g_silence_1000ms_audio_data_size = 16000;
extern const int16_t g_silence_1000ms_audio_data[];
