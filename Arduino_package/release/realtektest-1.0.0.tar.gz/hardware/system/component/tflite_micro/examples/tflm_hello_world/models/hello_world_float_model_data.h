#include <cstdint>

constexpr unsigned int g_hello_world_float_model_data_size = 3164;
extern const unsigned char g_hello_world_float_model_data[];
