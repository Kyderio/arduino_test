#include <cstdint>

constexpr unsigned int g_input_int8_test_data_size = 78400;
extern const int8_t g_input_int8_test_data[];
