#include <cstdint>

constexpr unsigned int g_model_int8_tflm_optimized_model_data_size = 60128;
extern const unsigned char g_model_int8_tflm_optimized_model_data[];
