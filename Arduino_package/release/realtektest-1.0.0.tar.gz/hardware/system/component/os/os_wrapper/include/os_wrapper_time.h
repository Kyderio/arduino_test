/*
 * Copyright (c) 2024 Realtek Semiconductor Corp.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef __OS_WRAPPER_TIME_H__
#define __OS_WRAPPER_TIME_H__

#define RTOS_TICK_RATE_HZ 1000UL
#define RTOS_TICK_RATE_MS (1000UL / RTOS_TICK_RATE_HZ)

#define RTOS_TIME_GET_PASSING_TIME_MS(start)           (rtos_time_get_current_system_time_ms() - (start))
#define RTOS_TIME_GET_TIME_INTERVAL_MS(start, end)     ((end) - (start))
#define RTOS_TIME_SET_MS_TO_SYSTIME(time)              (time / RTOS_TICK_RATE_MS)
#define RTOS_TIME_SET_SYSTIME_TO_MS(tick)              (tick * RTOS_TICK_RATE_MS)

/**
 * @brief  Compares two timestamps to determine if time1 is chronologically after or equal to time2,
 *         automatically handling 32-bit timer overflow/wrap-around conditions.
 *         Equivalent to the Linux kernel's time_after_eq(time1, time2).
 * @param  time1: The first timestamp to compare (e.g., current time)
 * @param  time2: The second timestamp to compare (e.g., expiration time)
 * @return TRUE if time1 is after or equal to time2; otherwise FALSE.
 */
#define rtos_time_after_eq(time1, time2) \
    (((int32_t)((uint32_t)(time1) - (uint32_t)(time2)) >= 0) ? TRUE : FALSE)

/**
 * @brief  If the current system is in a scheduling and non-interrupted state, it will switch to other tasks.
 *         Otherwise, the nop instruction will be executed.
 * @param  ms: Delay time in milliseconds
 */
void rtos_time_delay_ms(uint32_t ms);

/**
 * @brief  The system will execute the nop instruction without scheduling.
 * @param  us: Delay time in microseconds
 */
void rtos_time_delay_us(uint32_t us);

/**
 * @brief  Get the count of ticks since rtos_sched_start was called, and convert the return value to milliseconds.
 * @note   This interface does not consider systick overflow issues. If need check overflow, please use rtos_time_get_current_system_time_ms_64bit.
 */
uint32_t rtos_time_get_current_system_time_ms(void);

/**
 * @brief  Get the count of ticks since rtos_sched_start was called, and convert the return value to milliseconds. Overflow handled.
 * @note   This API return 64-bits value.
 */
uint64_t rtos_time_get_current_system_time_ms_64bit(void);

/**
 * @brief  Get the count of pended ticks since rtos_sched_suspend was called, and convert the return value to milliseconds.
 */
uint32_t rtos_time_get_current_pended_time_ms(void);

/**
 * @brief  Return value to in microseconds.
 * @note   This interface does not consider systick overflow issues.
 */
uint64_t rtos_time_get_current_system_time_us(void);

/**
 * @brief  Return value to in nanoseconds.
 * @note   This interface does not consider systick overflow issues. The accuracy is the clk frequency of the CPU
 */
uint64_t rtos_time_get_current_system_time_ns(void);

#endif
