

enum {
	MP_WOW_ENABLE,
	MP_WOW_SET_PATTERN,
};

extern struct iw_handler_def whc_fullmac_host_handlers_def;


