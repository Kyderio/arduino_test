
#define CONFIG_WHC_HOST 1
#define CONFIG_WLAN 1
#define CONFIG_ARM_CORE_CM4 1
//#define CONFIG_FULLMAC	1
#define CONFIG_WIFI_BRIDGE	1
#define CONFIG_WHC_HOST	1
#define CONFIG_NO_AMEBA	1

#define CONFIG_LWIP_LAYER 1

/* for sdio, need select amebaplus and amebagreen2 */
#define CONFIG_AMEBADPLUS 1

