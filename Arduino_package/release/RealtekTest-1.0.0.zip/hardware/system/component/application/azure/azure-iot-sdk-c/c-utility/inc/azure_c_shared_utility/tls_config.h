#ifndef __TLS_CONFIG_H__
#define __TLS_CONFIG_H__

// DEPRECATED: This file will be removed from the tree.

// WolfSSL or mbedTLS
//#define USE_WOLF_SSL
#define USE_MBED_TLS

#endif // __TLS_CONFIG_H__