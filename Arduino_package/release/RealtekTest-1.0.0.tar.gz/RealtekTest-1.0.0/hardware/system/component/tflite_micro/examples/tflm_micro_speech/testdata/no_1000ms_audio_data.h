#include <cstdint>

constexpr unsigned int g_no_1000ms_audio_data_size = 16000;
extern const int16_t g_no_1000ms_audio_data[];
