#include <cstdint>

constexpr unsigned int g_label_int8_test_data_size = 100;
extern const int8_t g_label_int8_test_data[];
